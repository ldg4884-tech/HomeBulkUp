package kr.co.homebulkup

import android.os.Bundle
import android.app.Activity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

private val Ink = Color(0xFF111713)
private val Panel = Color(0xFF1C241F)
private val Panel2 = Color(0xFF252F29)
private val Lime = Color(0xFFC6F36A)
private val Muted = Color(0xFF9BA99F)
private val White = Color(0xFFF3F6F1)
private val Orange = Color(0xFFFFB86B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { HomeBulkUpApp() } }
}

data class Exercise(val name: String, val detail: String, val sets: Int, val reps: String)
data class WorkoutDay(val day: String, val title: String, val subtitle: String, val exercises: List<Exercise>)

private val program = listOf(
    WorkoutDay("월요일", "가슴 · 어깨 · 삼두", "PUSH DAY · 상체 두께", listOf(Exercise("덤벨 플로어 프레스", "가슴", 3, "8–12회"), Exercise("푸시업", "가슴 · 삼두", 2, "8–15회"), Exercise("덤벨 숄더 프레스", "어깨", 2, "8–12회"), Exercise("덤벨 레터럴 레이즈", "측면 어깨", 3, "12–20회"), Exercise("오버헤드 트라이셉스 익스텐션", "삼두", 2, "10–15회"))),
    WorkoutDay("화요일", "등 · 이두", "PULL DAY · 등 넓이", listOf(Exercise("원암 덤벨 로우", "등", 3, "10–15회/측"), Exercise("벤트오버 덤벨 로우", "등", 2, "10–15회"), Exercise("문틀 철봉 턱걸이", "등 · 이두", 2, "가능한 만큼"), Exercise("덤벨 컬", "이두", 3, "10–15회"), Exercise("해머 컬", "전완 · 이두", 2, "10–15회"))),
    WorkoutDay("목요일", "하체 · 코어", "LEG DAY · 균형 잡힌 성장", listOf(Exercise("고블릿 스쿼트", "허벅지", 3, "10–15회"), Exercise("덤벨 루마니안 데드리프트", "햄스트링 · 둔근", 3, "10–15회"), Exercise("리버스 런지", "하체", 2, "8–12회/측"), Exercise("글루트 브리지", "둔근", 2, "12–20회"), Exercise("데드버그", "코어", 2, "8–10회/측"))),
    WorkoutDay("금요일", "가슴 · 등 · 어깨", "UPPER DAY · 상체 볼륨", listOf(Exercise("푸시업", "가슴", 3, "8–15회"), Exercise("원암 덤벨 로우", "등", 3, "10–15회/측"), Exercise("덤벨 숄더 프레스", "어깨", 2, "8–12회"), Exercise("덤벨 레터럴 레이즈", "측면 어깨", 2, "12–20회"), Exercise("덤벨 컬", "이두", 2, "10–15회")))
)

@Composable fun HomeBulkUpApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("homebulkup", 0) }
    var tab by remember { mutableIntStateOf(0) }
    var weight by remember { mutableStateOf(prefs.getString("weight", "74.0") ?: "74.0") }
    var goalWeight by remember { mutableStateOf(prefs.getString("goal", "80.0") ?: "80.0") }
    var completed by remember { mutableStateOf(loadCompleted(prefs)) }
    var weightHistory by remember { mutableStateOf(loadWeightHistory(prefs)) }
    var selectedDay by remember { mutableIntStateOf(0) }
    var protein by remember { mutableStateOf(prefs.getString("protein", "120") ?: "120") }
    var calories by remember { mutableStateOf(prefs.getString("calories", "2600") ?: "2600") }
    var timer by remember { mutableIntStateOf(90) }
    var timerRemaining by remember { mutableIntStateOf(90) }
    var timerRunning by remember { mutableStateOf(false) }
    var showTimer by remember { mutableStateOf(false) }
    var dataMessage by remember { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                val backup = JSONObject().put("app", "HomeBulkUp").put("backupVersion", 1).put("exportedAt", System.currentTimeMillis())
                val values = JSONObject()
                prefs.all.forEach { (key, value) ->
                    when (value) {
                        is String -> values.put(key, value)
                        is Boolean -> values.put(key, value)
                        is Int -> values.put(key, value)
                        is Long -> values.put(key, value)
                        is Float -> values.put(key, value.toDouble())
                    }
                }
                backup.put("preferences", values)
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(backup.toString(2)) }
                dataMessage = "백업 파일을 저장했어요. 다른 기기에 보관해 두세요."
            } catch (e: Exception) { dataMessage = "백업 실패: ${e.message ?: "파일을 저장할 수 없어요."}" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalArgumentException("파일을 읽을 수 없어요.")
                val backup = JSONObject(raw)
                require(backup.optString("app") == "HomeBulkUp" && backup.optInt("backupVersion") == 1) { "홈벌크업 백업 파일이 아니거나 버전이 맞지 않아요." }
                val values = backup.getJSONObject("preferences")
                val editor = prefs.edit().clear()
                values.keys().forEach { key ->
                    val value = values.get(key)
                    when (value) {
                        is String -> editor.putString(key, value)
                        is Boolean -> editor.putBoolean(key, value)
                        is Int -> editor.putInt(key, value)
                        is Long -> editor.putLong(key, value)
                        is Double -> editor.putFloat(key, value.toFloat())
                    }
                }
                editor.commit()
                dataMessage = "복원 완료! 화면을 새로고침할게요."
                (context as? Activity)?.recreate()
            } catch (e: Exception) { dataMessage = "복원 실패: ${e.message ?: "백업 파일을 확인해 주세요."}" }
        }
    }
    LaunchedEffect(showTimer, timerRunning) {
        while (showTimer && timerRunning && timerRemaining > 0) { delay(1000); timerRemaining -= 1 }
        if (timerRemaining == 0) timerRunning = false
    }
    fun saveWeight(value: String) {
        weight = value
        prefs.edit().putString("weight", value).apply()
        val date = todayKey()
        val parsed = value.toFloatOrNull()
        if (parsed != null && parsed > 0f) {
            weightHistory = (weightHistory.filterNot { it.first == date } + (date to parsed)).sortedBy { it.first }
            saveWeightHistory(prefs, weightHistory)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Lime, background = Ink, surface = Panel, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = White) {
                listOf("홈", "운동", "기록", "영양", "설정").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(when(i){0->Icons.Default.Home;1->Icons.Default.FitnessCenter;2->Icons.Default.ShowChart;3->Icons.Default.Restaurant;else->Icons.Default.Settings}, null) }, label = { Text(label, fontSize = 11.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Ink, selectedTextColor = Lime, indicatorColor = Lime, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when(tab) {
                    0 -> HomeScreen(weight, goalWeight, completedThisWeek(completed), onWeight = { saveWeight(it) }, onGoal = { goalWeight = it; prefs.edit().putString("goal", it).apply() }, onWorkout = { tab = 1 })
                    1 -> WorkoutScreen(selectedDay, { selectedDay = it }, completed, { index -> val key = "${todayKey()}-$index"; completed = completed.toMutableSet().also { if (!it.add(key)) it.remove(key) }; saveCompleted(prefs, completed) }, prefs, { showTimer = true; timerRemaining = timer; timerRunning = false })
                    2 -> RecordsScreen(weight, goalWeight, completedThisWeek(completed), completed, weightHistory, onWeight = { saveWeight(it) }, onGoal = { goalWeight = it; prefs.edit().putString("goal", it).apply() })
                    3 -> NutritionScreen(protein, calories, { protein = it; prefs.edit().putString("protein", it).apply() }, { calories = it; prefs.edit().putString("calories", it).apply() })
                    else -> DataManagementScreen(
                        onExport = { exportLauncher.launch("homebulkup-backup-${todayKey()}.json") },
                        onImport = { importLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream")) },
                        onReset = { dataMessage = "백업 파일을 먼저 저장한 뒤 복원하는 것을 권장해요. 앱 데이터 초기화는 Android 설정에서 진행할 수 있어요." }
                    )
                }
                if (dataMessage != null) AlertDialog(onDismissRequest = { dataMessage = null }, containerColor = Panel, title = { Text("데이터 관리", color = White) }, text = { Text(dataMessage ?: "", color = Muted) }, confirmButton = { TextButton(onClick = { dataMessage = null }) { Text("확인", color = Lime) } })
                if (showTimer) AlertDialog(onDismissRequest = { showTimer = false; timerRunning = false }, containerColor = Panel, title = { Text("세트 휴식 타이머", color = White) }, text = { Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) { Text("${timerRemaining}초", color = Lime, fontSize = 42.sp, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { OutlinedButton(onClick = { timerRemaining = (timerRemaining - 15).coerceAtLeast(15); timer = timerRemaining }, enabled = !timerRunning) { Text("-15초") }; OutlinedButton(onClick = { timerRemaining = (timerRemaining + 15).coerceAtMost(300); timer = timerRemaining }, enabled = !timerRunning) { Text("+15초") } }; Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { if (timerRemaining <= 0) timerRemaining = timer; timerRunning = !timerRunning }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Text(if (timerRunning) "일시정지" else "시작") }; OutlinedButton(onClick = { timerRunning = false; timerRemaining = timer; }) { Text("초기화") } }; Text(if (timerRemaining == 0) "휴식 완료! 다음 세트를 시작하세요." else "운동 세트 사이에 호흡을 정리하세요.", color = Muted, fontSize = 12.sp) } }, confirmButton = { TextButton(onClick = { showTimer = false; timerRunning = false }) { Text("닫기", color = Lime) } })
            }
        }
    }
}

@Composable private fun HomeScreen(weight: String, goal: String, count: Int, onWeight:(String)->Unit, onGoal:(String)->Unit, onWorkout:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text("HOME BULK UP", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("오늘도 한 단계 성장", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold) }; Box(Modifier.size(44.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.FitnessCenter, null, tint = Lime) } } }
        item { Column(Modifier.fillMaxWidth().background(Lime, RoundedCornerShape(24.dp)).padding(20.dp)) { Text("YOUR 12-WEEK JOURNEY", color = Ink.copy(alpha=.7f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp); Spacer(Modifier.height(8.dp)); Text("크게, 꾸준하게.", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Black); Text("덤벨과 철봉으로 만드는 나만의 루틴", color = Ink.copy(alpha=.75f), fontSize = 13.sp); Spacer(Modifier.height(18.dp)); Row(verticalAlignment = Alignment.Bottom) { Column(Modifier.weight(1f)) { Text("현재 체중", color = Ink.copy(alpha=.65f), fontSize = 12.sp); Text("${weight.ifBlank { "74.0" }} kg", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold) }; Column(horizontalAlignment = Alignment.End) { Text("목표 ${goal.ifBlank { "80.0" }} kg", color = Ink.copy(alpha=.7f), fontSize = 12.sp); Text("${progress(weight, goal)}%", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold) } }; Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { progress(weight, goal)/100f }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Ink, trackColor = Ink.copy(alpha=.16f)) } }
        item { SectionTitle("오늘의 미션", "운동을 완료하고 기록을 쌓아봐") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("이번 주 운동", "$count / 4", "완료 세션", Modifier.weight(1f)); StatCard("단백질 목표", "120–150g", "하루 기준", Modifier.weight(1f)) } }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(46.dp).background(Lime.copy(alpha=.15f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Lime) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("오늘의 추천 운동", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("${todayWorkout().title} · 35–45분", color = Muted, fontSize = 12.sp) }; Icon(Icons.Default.ArrowForward, null, tint = Lime) }; Spacer(Modifier.height(16.dp)); Button(onClick = onWorkout, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink), shape = RoundedCornerShape(14.dp)) { Text("운동 시작하기", fontWeight = FontWeight.Bold) } } }
        item { Text("성장 원칙", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MiniTip("01", "점진적 과부하", "횟수가 편해지면 덤벨 무게를 조금씩 올려요.", Modifier.weight(1f)); MiniTip("02", "회복도 훈련", "수면과 휴식일을 운동만큼 챙겨요.", Modifier.weight(1f)) } }
        item { Text("* 체중은 매일 비슷한 시간에 측정하고 주간 평균으로 추세를 확인하세요.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun WorkoutScreen(selected: Int, select:(Int)->Unit, completed:Set<String>, toggle:(Int)->Unit, prefs: android.content.SharedPreferences, timer:()->Unit) {
    val day = program[selected]
    val dateKey = todayKey()
    var logs by remember(dateKey) { mutableStateOf(loadExerciseLogs(prefs)) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("TRAINING PLAN", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("운동 프로그램", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text("첫 2주는 무리하지 말고 2–4회 여유를 남겨요.", color = Muted, fontSize = 12.sp) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { program.forEachIndexed { i, d -> Column(Modifier.weight(1f).background(if (selected==i) Lime else Panel, RoundedCornerShape(12.dp)).clickable { select(i) }.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(d.day.take(1), color = if(selected==i) Ink else Muted, fontSize = 11.sp); Text(listOf("PUSH","PULL","LEGS","UPPER")[i], color = if(selected==i) Ink else White, fontSize = 10.sp, fontWeight = FontWeight.Bold) } } } }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)) { Text(day.subtitle, color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp); Text(day.title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("${day.exercises.sumOf { it.sets }}세트 · 약 35–45분", color = Muted, fontSize = 12.sp) } }
        itemsIndexed(day.exercises) { idx, exercise ->
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).background(Panel2, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) { Text("${idx+1}".padStart(2,'0'), color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(exercise.name, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("${exercise.detail} · ${exercise.sets}세트 × ${exercise.reps}", color = Muted, fontSize = 11.sp)
                    }
                }
                val priorSet = (0 until exercise.sets).map { setNo ->
                    val suffix = "-$selected-$idx-set-${setNo+1}-weight"
                    logs.entries.filter { it.key.endsWith(suffix) && !it.key.startsWith(dateKey) }
                        .maxByOrNull { it.key.substringBefore(suffix) }?.value.orEmpty()
                }
                if (priorSet.any { it.isNotBlank() }) {
                    Text("이전 세트 무게: ${priorSet.mapIndexedNotNull { i, v -> if (v.isNotBlank()) "${i+1}세트 ${v}kg" else null }.joinToString(" · ")}", color = Lime, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                }
                Spacer(Modifier.height(8.dp))
                repeat(exercise.sets) { setIndex ->
                    val setNo = setIndex + 1
                    val weightKey = "$dateKey-$selected-$idx-set-$setNo-weight"
                    val repsKey = "$dateKey-$selected-$idx-set-$setNo-reps"
                    var setWeight by remember(weightKey) { mutableStateOf(logs[weightKey] ?: "") }
                    var setReps by remember(repsKey) { mutableStateOf(logs[repsKey] ?: "") }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                        Text("$setNo 세트", color = Muted, fontSize = 12.sp, modifier = Modifier.width(48.dp))
                        OutlinedTextField(value = setWeight, onValueChange = { value ->
                            setWeight = value
                            logs = logs + (weightKey to value)
                            saveExerciseLogs(prefs, logs)
                        }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("무게 kg", fontSize = 10.sp) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Lime, unfocusedBorderColor = Panel2, focusedLabelColor = Lime, unfocusedLabelColor = Muted))
                        OutlinedTextField(value = setReps, onValueChange = { value ->
                            setReps = value
                            logs = logs + (repsKey to value)
                            saveExerciseLogs(prefs, logs)
                        }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("횟수", fontSize = 10.sp) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Lime, unfocusedBorderColor = Panel2, focusedLabelColor = Lime, unfocusedLabelColor = Muted))
                    }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedButton(onClick = timer, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Lime)) { Icon(Icons.Default.Timer, null); Spacer(Modifier.width(6.dp)); Text("휴식 타이머") }; Button(onClick = { toggle(selected) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if("${todayKey()}-$selected" in completed) Panel2 else Lime, contentColor = if("${todayKey()}-$selected" in completed) White else Ink)) { Icon(if("${todayKey()}-$selected" in completed) Icons.Default.CheckCircle else Icons.Default.Check, null); Spacer(Modifier.width(6.dp)); Text(if("${todayKey()}-$selected" in completed) "완료 취소" else "운동 완료") } } }
        item { Text("오늘 입력한 운동별 무게와 메모는 저장돼요. 다음 운동 때 기록을 비교하며 조금씩 발전시켜 보세요.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun RecordsScreen(weight:String, goal:String, count:Int, completed:Set<String>, history:List<Pair<String,Float>>, onWeight:(String)->Unit, onGoal:(String)->Unit) {
    var showWeight by remember { mutableStateOf(false) }; var showGoal by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("YOUR PROGRESS", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("성장 기록", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text("작은 변화가 모여 큰 차이를 만듭니다.", color = Muted, fontSize = 13.sp) }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(20.dp)) { Text("현재 체중", color = Muted, fontSize = 12.sp); Row(verticalAlignment = Alignment.Bottom) { Text("$weight", color = White, fontSize = 38.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(6.dp)); Text("kg", color = Lime, fontSize = 15.sp); Spacer(Modifier.weight(1f)); TextButton(onClick = { showWeight = true }) { Text("수정", color = Lime) } }; HorizontalDivider(color = Panel2); Spacer(Modifier.height(14.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("목표 체중", color = Muted, fontSize = 12.sp); Text("$goal kg", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }; TextButton(onClick = { showGoal = true }) { Text("목표 설정", color = Lime) } }; LinearProgressIndicator(progress = { progress(weight, goal)/100f }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Lime, trackColor = Panel2) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("완료한 운동", "$count 회", "선택한 프로그램 기준", Modifier.weight(1f)); StatCard("목표 증가량", "+${(goal.toFloatOrNull()?:80f)-(weight.toFloatOrNull()?:74f)} kg", "현재 설정 기준", Modifier.weight(1f)) } }
        item { Text("최근 4주 운동 달력", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("월", "화", "수", "목", "금", "토", "일").forEach { Text(it, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
                }
                val calendarDays = remember {
                    val cal = java.util.Calendar.getInstance()
                    cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
                    cal.add(java.util.Calendar.DAY_OF_YEAR, -27)
                    (0 until 28).map {
                        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                        val dayNumber = cal.get(java.util.Calendar.DAY_OF_MONTH)
                        cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                        key to dayNumber
                    }
                }
                calendarDays.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        week.forEach { (date, number) ->
                            val didWorkout = completed.any { it.startsWith("$date-") }
                            Column(Modifier.weight(1f).padding(vertical = 5.dp).background(if (didWorkout) Lime else Panel2, RoundedCornerShape(9.dp)).padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(number.toString(), color = if (didWorkout) Ink else White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(if (didWorkout) "✓" else "·", color = if (didWorkout) Ink else Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(9.dp).background(Lime, CircleShape)); Spacer(Modifier.width(6.dp)); Text("운동 완료", color = Muted, fontSize = 11.sp); Spacer(Modifier.width(12.dp)); Text("날짜를 기준으로 완료한 운동을 표시해요.", color = Muted, fontSize = 11.sp) }
            }
        }
        item { Text("체중 변화 그래프", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
            if (history.size < 2) Text("서로 다른 날짜에 체중을 2회 이상 기록하면 그래프가 표시돼요.", color = Muted, fontSize = 13.sp)
            else {
                WeightTrendChart(history.takeLast(14).map { it.second })
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatDate(history.takeLast(14).first().first), color = Muted, fontSize = 10.sp)
                    Text(formatDate(history.last().first), color = Muted, fontSize = 10.sp)
                }
            }
        } }
        item { Text("체중 변화 기록", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
            if (history.isEmpty()) Text("체중을 저장하면 날짜별 기록이 여기에 쌓여요.", color = Muted, fontSize = 13.sp)
            else {
                val recent = history.takeLast(10).reversed()
                recent.forEachIndexed { index, item ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(formatDate(item.first), color = Muted, fontSize = 12.sp)
                        Text(String.format(Locale.getDefault(), "%.1f kg", item.second), color = if(index == 0) Lime else White, fontWeight = FontWeight.Bold)
                    }
                    if(index != recent.lastIndex) HorizontalDivider(color = Panel2)
                }
                if (history.size >= 2) { val delta = history.last().second - history.first().second; Text("첫 기록 대비 ${if(delta >= 0) "+" else ""}${String.format(Locale.getDefault(), "%.1f", delta)} kg", color = Lime, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            }
        } }
        item { Text("체중 기록 가이드", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) { Text("01  매일 같은 조건으로 측정", color = Lime, fontWeight = FontWeight.Bold); Text("기상 후 화장실을 다녀온 뒤, 식사 전 측정하면 비교하기 좋아요.", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(14.dp)); Text("02  주간 평균을 확인", color = Lime, fontWeight = FontWeight.Bold); Text("하루 수치보다 2–3주 동안의 추세를 보고 섭취량을 조절하세요.", color = Muted, fontSize = 13.sp) } }
        item { Text("체중은 날짜별로 저장되며 같은 날 다시 입력하면 해당 날짜의 기록이 갱신돼요.", color = Muted, fontSize = 11.sp) }
    }
    if(showWeight) NumberDialog("현재 체중 (kg)", weight, { showWeight=false }, onWeight)
    if(showGoal) NumberDialog("목표 체중 (kg)", goal, { showGoal=false }, onGoal)
}

@Composable private fun WeightTrendChart(values: List<Float>) {
    val minValue = (values.minOrNull() ?: 0f) - 0.5f
    val maxValue = (values.maxOrNull() ?: 1f) + 0.5f
    val range = (maxValue - minValue).coerceAtLeast(1f)
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val left = 12f; val right = size.width - 12f
        val top = 12f; val bottom = size.height - 12f
        repeat(3) { i ->
            val y = top + (bottom - top) * i / 2f
            drawLine(Panel2, Offset(left, y), Offset(right, y), strokeWidth = 1.dp.toPx())
        }
        val points = values.mapIndexed { index, value ->
            val x = if (values.size == 1) (left + right) / 2f else left + (right - left) * index / (values.size - 1).toFloat()
            val y = bottom - ((value - minValue) / range) * (bottom - top)
            Offset(x, y)
        }
        points.zipWithNext().forEach { (a, b) -> drawLine(Lime, a, b, strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round) }
        points.forEach { drawCircle(Lime, radius = 4.dp.toPx(), center = it) }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(String.format(Locale.getDefault(), "최저 %.1fkg", values.minOrNull() ?: 0f), color = Muted, fontSize = 11.sp)
        Text(String.format(Locale.getDefault(), "최고 %.1fkg", values.maxOrNull() ?: 0f), color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun NutritionScreen(protein:String, calories:String, onProtein:(String)->Unit, onCalories:(String)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("FUEL YOUR GROWTH", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("영양 관리", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text("근육은 운동과 영양, 회복이 함께 만듭니다.", color = Muted, fontSize = 13.sp) }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(20.dp)) { Text("하루 목표", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("단백질", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold); Text("근육 회복과 성장", color = Muted, fontSize = 11.sp) }; OutlinedTextField(value = protein, onValueChange = onProtein, modifier = Modifier.width(115.dp), singleLine = true, suffix = { Text("g") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Lime, unfocusedBorderColor = Panel2)) }; Spacer(Modifier.height(16.dp)); HorizontalDivider(color = Panel2); Spacer(Modifier.height(16.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("칼로리", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold); Text("체중 증가용 시작 목표", color = Muted, fontSize = 11.sp) }; OutlinedTextField(value = calories, onValueChange = onCalories, modifier = Modifier.width(130.dp), singleLine = true, suffix = { Text("kcal") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Lime, unfocusedBorderColor = Panel2)) } } }
        item { Text("간단한 벌크업 원칙", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        item { MiniTip("01", "단백질을 나눠 먹기", "매끼 단백질 식품을 포함하고 하루 목표를 여러 끼니로 나눠요.", Modifier.fillMaxWidth()) }
        item { MiniTip("02", "조금씩 더 먹기", "체중이 2주간 거의 늘지 않으면 하루 섭취량을 100–150kcal 정도 늘려보세요.", Modifier.fillMaxWidth()) }
        item { MiniTip("03", "숫자는 출발점", "칼로리 목표는 추정치예요. 활동량과 체중 추세에 맞춰 조절하세요.", Modifier.fillMaxWidth()) }
        item { Text("안내: 신장 질환 등 단백질 섭취에 제한이 필요한 건강 문제가 있다면 의료진과 상의하세요.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun DataManagementScreen(onExport: () -> Unit, onImport: () -> Unit, onReset: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("SETTINGS", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("데이터 관리", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text("운동 기록을 안전하게 보관하세요.", color = Muted, fontSize = 13.sp) }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CloudDownload, null, tint = Lime, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)); Column { Text("백업 파일 내보내기", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("체중·목표·운동 완료·세트 기록·영양 설정을 JSON으로 저장", color = Muted, fontSize = 12.sp) } }
            Spacer(Modifier.height(14.dp)); Button(onClick = onExport, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(8.dp)); Text("백업 파일 저장") }
        } }
        item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Restore, null, tint = Lime, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)); Column { Text("백업 파일 복원", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("선택한 백업의 데이터로 현재 앱 기록을 교체합니다.", color = Muted, fontSize = 12.sp) } }
            Spacer(Modifier.height(10.dp)); Text("주의: 복원하면 현재 앱 데이터가 백업 파일의 내용으로 바뀝니다. 먼저 현재 기록을 백업해 두세요.", color = Orange, fontSize = 12.sp, lineHeight = 17.sp)
            Spacer(Modifier.height(14.dp)); OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Lime)) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("백업 파일 선택") }
        } }
        item { Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(18.dp)).padding(16.dp)) { Text("백업에 포함되는 정보", color = White, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); listOf("현재 체중과 목표 체중", "날짜별 체중 기록", "운동 완료 기록", "세트별 무게와 반복 횟수", "단백질·칼로리 목표").forEach { Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) { Icon(Icons.Default.CheckCircle, null, tint = Lime, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Text(it, color = Muted, fontSize = 13.sp) } } } }
        item { Text("백업 파일은 휴대폰 외부나 클라우드 등 안전한 위치에 보관하세요. 앱 데이터 삭제나 휴대폰 분실에 대비해 정기적으로 백업하는 것을 권장합니다.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp) }
    }
}

@Composable private fun SectionTitle(title:String, subtitle:String) { Column { Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp) } }
@Composable private fun StatCard(title:String, value:String, caption:String, modifier:Modifier=Modifier) { Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) { Text(title, color = Muted, fontSize = 11.sp); Spacer(Modifier.height(7.dp)); Text(value, color = White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Text(caption, color = Muted, fontSize = 10.sp) } }
@Composable private fun MiniTip(number:String, title:String, text:String, modifier:Modifier=Modifier) { Row(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.Top) { Text(number, color = Lime, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.width(10.dp)); Column { Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(text, color = Muted, fontSize = 11.sp, lineHeight = 16.sp) } } }
@Composable private fun NumberDialog(title:String, value:String, dismiss:()->Unit, save:(String)->Unit) { var input by remember { mutableStateOf(value) }; AlertDialog(onDismissRequest = dismiss, containerColor = Panel, title = { Text(title, color = White) }, text = { OutlinedTextField(value = input, onValueChange = { input=it }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Lime, unfocusedBorderColor = Panel2)) }, confirmButton = { TextButton(onClick = { if(input.toFloatOrNull()!=null) save(input); dismiss() }) { Text("저장", color = Lime) } }, dismissButton = { TextButton(onClick = dismiss) { Text("취소", color = Muted) } }) }
private fun progress(weight:String, goal:String):Int { val w=weight.toFloatOrNull()?:74f; val g=goal.toFloatOrNull()?:80f; return if(g<=0) 0 else ((w/g)*100).toInt().coerceIn(0,100) }
private fun todayWorkout():WorkoutDay { val d = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK); return when(d) { java.util.Calendar.MONDAY -> program[0]; java.util.Calendar.TUESDAY -> program[1]; java.util.Calendar.THURSDAY -> program[2]; java.util.Calendar.FRIDAY -> program[3]; else -> program[0] } }
private fun loadCompleted(prefs:android.content.SharedPreferences):Set<String> = try { val a=JSONArray(prefs.getString("completed", "[]")); (0 until a.length()).map { a.optString(it) }.filter { it.contains("-") }.toSet() } catch (_:Exception) { emptySet() }
private fun saveCompleted(prefs:android.content.SharedPreferences, set:Set<String>) { val a=JSONArray(); set.sorted().forEach { a.put(it) }; prefs.edit().putString("completed", a.toString()).apply() }
private fun completedThisWeek(set: Set<String>): Int {
    val cal = java.util.Calendar.getInstance(); cal.set(java.util.Calendar.DAY_OF_WEEK, cal.firstDayOfWeek); cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
    val start = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    return set.count { it.substringBeforeLast("-") >= start }
}


private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun formatDate(key: String): String = try { val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key); SimpleDateFormat("M월 d일", Locale.KOREAN).format(d ?: Date()) } catch (_: Exception) { key }
private fun loadWeightHistory(prefs: android.content.SharedPreferences): List<Pair<String, Float>> = try {
    val arr = JSONArray(prefs.getString("weight_history", "[]"))
    (0 until arr.length()).mapNotNull { i -> val o = arr.getJSONObject(i); val v = o.optDouble("weight", Double.NaN); if (v.isNaN()) null else o.optString("date") to v.toFloat() }.sortedBy { it.first }
} catch (_: Exception) { emptyList() }
private fun saveWeightHistory(prefs: android.content.SharedPreferences, history: List<Pair<String, Float>>) {
    val arr = JSONArray(); history.forEach { (date, weight) -> arr.put(JSONObject().put("date", date).put("weight", weight)) }
    prefs.edit().putString("weight_history", arr.toString()).apply()
}
private fun loadExerciseLogs(prefs: android.content.SharedPreferences): Map<String, String> = try {
    val obj = JSONObject(prefs.getString("exercise_logs", "{}")); obj.keys().asSequence().associateWith { obj.optString(it, "") }
} catch (_: Exception) { emptyMap() }
private fun saveExerciseLogs(prefs: android.content.SharedPreferences, logs: Map<String, String>) {
    val obj = JSONObject(); logs.forEach { (key, value) -> obj.put(key, value) }; prefs.edit().putString("exercise_logs", obj.toString()).apply()
}
